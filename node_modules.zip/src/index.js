import dotenv from "dotenv";
import express from "express";
import connectDB from "./db/index.js";
import userRoutes from "./routes/user.routes.js"; // Import your user routes

dotenv.config({ path: './.env' });

const app = express();

// ✅ Middleware to parse JSON (Fixes Thunder Client request issue)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ✅ Use API routes
app.use("/api/user", userRoutes);  // Ensure correct route prefix

// Connect to MongoDB and start server
connectDB()
  .then(() => {
    app.listen(process.env.PORT || 8000, () => {
      console.log(`Server is running on port: ${process.env.PORT || 8000}`);
    });
  })
  .catch((err) => {
    console.log("MongoDB connection failed !!!", err);
  });
